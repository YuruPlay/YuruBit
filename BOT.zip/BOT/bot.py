import os
import json
import requests

# 📁 Rutas
CARPETA = "/storage/emulated/0/Download/BOT"
CONFIG_PATH = os.path.join(CARPETA, "config.json")
PERSONALIDAD_PATH = os.path.join(CARPETA, "personalidad.txt")
HISTORIAL_PATH = os.path.join(CARPETA, "historial.json")

# 📂 Crear carpeta si no existe
if not os.path.exists(CARPETA):
    os.makedirs(CARPETA)

# 🧠 Cargar config
with open(CONFIG_PATH, "r", encoding="utf-8") as f:
    config = json.load(f)

# 🔹 Cargar personalidad
def cargar_personalidad():
    if os.path.exists(PERSONALIDAD_PATH):
        with open(PERSONALIDAD_PATH, "r", encoding="utf-8") as f:
            return f.read()
    return "Eres un asistente con emociones."

# 🔹 Historial
def cargar_historial():
    if os.path.exists(HISTORIAL_PATH):
        with open(HISTORIAL_PATH, "r", encoding="utf-8") as f:
            return json.load(f)
    return []

def guardar_historial(historial):
    with open(HISTORIAL_PATH, "w", encoding="utf-8") as f:
        json.dump(historial[-30:], f, indent=2)

# 🎮 Menú personalizado
def mostrar_menu():
    return (
        "╭── 🎮 MENÚ DE YuruBit ──╮\n"
        "│ 💬 #hablar  → Chat normal\n"
        "│ 🎲 #juego   → Jugar algo divertido\n"
        "│ 🧠 #info    → Información del bot\n"
        "│ 🔄 #reset   → Reiniciar historial\n"
        "│ ❌ salir    → Cerrar el bot\n"
        "╰────────────────────────╯"
    )

def jugar_algo():
    return "🎲 ¡Vamos a jugar piedra, papel o tijera! Escribe uno para comenzar."

def mostrar_info():
    return "🧠 Soy YuruBit, un bot emocional creado por Yuruan. Me encanta ayudarte con ideas, juegos y programación. 🤖💙"

def resetear_historial():
    guardar_historial([])
    return "🔄 ¡He olvidado todo! Comenzamos desde cero 😊"

# 🧠 IA vía OpenRouter con fallback de modelos si hay error 429
def obtener_respuesta(mensaje_usuario, historial):
    mensajes = [{"role": "system", "content": cargar_personalidad()}] + historial + [{"role": "user", "content": mensaje_usuario}]
    
    modelos_alternativos = [
        "gryphe/mythomax-l2-13b:free",
        "nousresearch/nous-capybara-7b:free",
        "openchat/openchat-7b:free",
        "deepseek/deepseek-r1-0528:free"
    ]

    intentos = [config["model"]] + modelos_alternativos

    for modelo in intentos:
        try:
            respuesta = requests.post(
                url="https://openrouter.ai/api/v1/chat/completions",
                headers={
                    "Authorization": f"Bearer {config['api_key']}",
                    "Content-Type": "application/json",
                    "HTTP-Referer": config["referer"],
                    "X-Title": config["title"]
                },
                json={
                    "model": modelo,
                    "messages": mensajes
                }
            )

            if respuesta.status_code == 401:
                return "🚫 Clave inválida o no autorizada. Revisa tu config.json."
            if respuesta.status_code == 403:
                return "🔒 No tienes permiso para usar este modelo gratuito o tu IP está bloqueada."
            if respuesta.status_code == 429:
                print(f"⚠️ Modelo saturado: {modelo}. Probando otro...")
                continue

            respuesta.raise_for_status()
            if modelo != config["model"]:
                print(f"🔁 Se usó un modelo alternativo: {modelo}")
            return respuesta.json()["choices"][0]["message"]["content"]

        except Exception as e:
            print("❌ Error al conectar:", e)

    return "⚠️ Todos los modelos fallaron. Intenta más tarde."

# 🚀 Inicio del chat
def iniciar_chat():
    os.system("clear")
    print("🤖 YuruBit con emociones y menú activado 💬✨\n")
    print(mostrar_menu())

    historial = cargar_historial()

    while True:
        entrada = input("\nTú: ")

        if entrada.lower() in ["salir", "exit"]:
            print("🛑 ¡Hasta pronto, Yuruan! 👋✨")
            break

        if entrada.lower() == "#menu":
            print(mostrar_menu())
            continue
        elif entrada.lower() == "#juego":
            print("YuruBit:", jugar_algo())
            continue
        elif entrada.lower() == "#info":
            print("YuruBit:", mostrar_info())
            continue
        elif entrada.lower() == "#reset":
            print("YuruBit:", resetear_historial())
            historial = []
            continue
        elif entrada.lower() == "#hablar":
            print("🗨️ Modo conversación activado.")
            continue

        respuesta = obtener_respuesta(entrada, historial)
        print("YuruBit:", respuesta)

        historial.append({"role": "user", "content": entrada})
        historial.append({"role": "assistant", "content": respuesta})
        guardar_historial(historial)

# Ejecutar
if __name__ == "__main__":
    iniciar_chat()